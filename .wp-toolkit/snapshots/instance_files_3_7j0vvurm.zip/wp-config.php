<?php


/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'blossom_20240722BlSh' );

/** Database username */
define( 'DB_USER', 'blossom_U20240722BlSh' );

/** Database password */
define( 'DB_PASSWORD', '@DRpi%W9bY*J' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Sy%#2;-/Vr=1.eX8 +^pjx]-rxFnDtw3c#2_Q6VPxdWV;<#,Dd>crG=x_3<Az,.&' );
define( 'SECURE_AUTH_KEY',   '.zyXQQ9j<EEvD0=tlG(<UTP14+iC5Gj7[&5%#s}$W`[)*u?V^$~Ez|{E`p+/4+n?' );
define( 'LOGGED_IN_KEY',     '<:-8 l--z<z|,-KgNq)re$8]u*&|msRHkZI?(!RaRN4|9sO>pa3.]TH,NmLy?!p[' );
define( 'NONCE_KEY',         'O|(>5rMq3HN,Nn)$9-*~4JhVW@VEXR7~Vf QZo,sCwWxGc;@e=q&q;LUuPX~Qd5j' );
define( 'AUTH_SALT',         'H+0!Bw{7.=O%WCX7B-ppmP4]o~{TsRHT:kCx4RK{pqaRa@]4H6J?yq=Gv<uE||@c' );
define( 'SECURE_AUTH_SALT',  'o|yK}I_?O9(5i]DFiJpPP}jr*n-O1ROfT(weGp;{+&?Et} :{mGYyT)K5t/8z{2+' );
define( 'LOGGED_IN_SALT',    'Wt/{%p4C]!yn-g4(E~p|!&w.=.JqM,x=s0VWEY/>V1}BC=5~M/o<C 1&S]%]j5vu' );
define( 'NONCE_SALT',        ':vS*aco_NS*d(7QLK}O<Fn6fTcp!L.Ne sXQ%.LsD<:tKn ^&J,{Q.ddTzd@$,pT' );
define( 'WP_CACHE_KEY_SALT', 'Gaq}q[}!VK)^sda,UGVK+n9Kj7,Rz&;/.iuHb$AVj7iYQ4cX[Y>FLzFuuJLtpz9;' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'MFXs3sp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
define( 'DUPLICATOR_AUTH_KEY', 'B7?lY1`3TJI?s2yw)4@L1t+]gPt,po@=`[7i>0O<x/!(u.=1A-L<n0s#:$;(G.7}' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
